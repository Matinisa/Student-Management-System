package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Student undergrad = new UndergraduateStudent.Builder("U100", "Alice")
                .email("alice@uni.com")
                .department("Computer Science")
                .creditHours(18)
                .scholarshipAmount(2000)
                .build();

        Student grad = new GraduateStudent.Builder("G200", "Bob")
                .email("bob@uni.com")
                .department("Engineering")
                .researchAssistant(true)
                .stipend(5000)
                .build();

        undergrad.displayStudentDetails();
        grad.displayStudentDetails();
    }
}
